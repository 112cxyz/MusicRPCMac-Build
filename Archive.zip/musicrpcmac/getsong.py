from datetime import timedelta
import os
import coverpy
from pypresence import Presence 
import time
client_id = "962077666754854942" 
RPC = Presence(client_id)
RPC.connect()	

coverpy = coverpy.CoverPy()
limit = 3

while True:
	a  = os.popen('osascript /Applications/musicrpcmac/get.scpt').readlines()
	time.sleep(5)
	if a[0] != "no\n":
		try:
			result = coverpy.get_cover(a[0], limit)
			RPC.update(large_image=result.artwork(400),state=result.name+"\n"+result.artist)
			print(result.name)
		except:
			print("Could not execute GET request")
	else:
		RPC.update(state="Not Playing")
		print("notplaying")
